using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Controller : MonoBehaviour
{
    public GameObject obstacle;

    public float spawnTime = 0.5f;

    float m_SpawnTime;
    int score;
    bool isGameOver;

    UIManager m_ui;

    // Start is called before the first frame update
    void Start()
    {
        m_SpawnTime = 0;
        m_ui = FindAnyObjectByType<UIManager>();
        m_ui.SetScoreText("Score: " + score);
    }

    // Update is called once per frame
    void Update()
    {
     
        if(isGameOver)
        {
            m_SpawnTime = 0;
            m_ui.ShowGameOverPanel(true);
            return;
        }

        m_SpawnTime -= Time.deltaTime;
        if (m_SpawnTime <= 0)
        {
            SpawnObstacle();
            m_SpawnTime = spawnTime;
        }
    }
    public void SpawnObstacle()
    {
        float randY = Random.Range(-0.27f, -1.5f);
        Vector2 spawnPos = new Vector2(12.37f, randY);
        if(obstacle)
        {
            Instantiate(obstacle, spawnPos, Quaternion.identity);
        }
    }
    public void SetScore(int value)
    {
        score = value;
    }

    public int GetScore()
    {
        return score;
    }

    public void ScoreIncrement()
    {
        score++;
        m_ui.SetScoreText("Score: " + score);
    }
    public bool IsGAMEOVER()
    {
        return isGameOver;
    }
    public void SetGameoverState(bool state)
    {
        isGameOver = state;
    }

    public void Replay()
    {
        SceneManager.LoadScene("GamePlay");
    }
}
