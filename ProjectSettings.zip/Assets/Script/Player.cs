using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float JumpForce; 

    bool IsGround;
    Rigidbody2D player;
    Controller m_gc;

    public AudioSource aus;
    public AudioClip JumpSound;
    public AudioClip LoseSound;
    // Start is called before the first frame update
    void Start()
    {
        player = GetComponent<Rigidbody2D>();
        m_gc = FindAnyObjectByType<Controller>();
    }

    // Update is called once per frame
    void Update()
    {
        bool IsJump = Input.GetKeyDown(KeyCode.Space);
        if(IsJump && IsGround)
        {
            player.AddForce(Vector2.up * JumpForce);
            IsGround = false;

            if(aus && JumpSound)
            {
                aus.PlayOneShot(JumpSound);
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if(col.gameObject.CompareTag("Ground"))
        {
            IsGround = true;
        }
    }
    private void OnTriggerEnter2D(Collider2D col)
    {
        if(col.CompareTag("Obstacle"))
        {
            m_gc.SetGameoverState(true);
            if(aus && LoseSound)
            {
                aus.PlayOneShot(LoseSound);
            }
        }
    }
}
